﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication10
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";


        protected void regis_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cnstring);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string a = "insert into signup(First_name, Last_name, Email, Password, month, day, year, Gender, Type_of_Movie_Buff)values('" + fname.Text.ToString() + "','" + lname.Text.ToString() + "','" + email.Text.ToString() + "','" + password.Text.ToString() + "','" + month.Text.ToString() + "','" + day.Text.ToString() + "','" + year.Text.ToString() + "','" + gender.Text.ToString() + "','" + moviebuff.Text.ToString() + "')";
                SqlCommand cmd = new SqlCommand(a, con);
                cmd.ExecuteNonQuery();
                Response.Write("Registered Successfully!!");
            }
            else
            {
                Response.Write("Connection is failed!!!!");
            }
        }
    }
}