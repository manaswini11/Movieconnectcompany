﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication10
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void signup_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void signin_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            string check = "select count(*) from [signup] where Email =' " + username.Text + " ' and password =' " + pass.Text + " ' ";
            SqlCommand com = new SqlCommand(check, con);
            con.Open();


            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

            con.Close();
            if (temp == 1)
            {

                Response.Redirect("profilepage.aspx");

            }
            else
            {
                Response.Write("username or password doesn't exist");
            }
        }
    }
}